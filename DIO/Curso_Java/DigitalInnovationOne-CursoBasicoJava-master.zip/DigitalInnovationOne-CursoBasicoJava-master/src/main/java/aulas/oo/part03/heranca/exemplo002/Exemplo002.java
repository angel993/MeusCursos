package aulas.oo.part03.heranca.exemplo002;

public class Exemplo002 {

    public static void main(String[] args) {

        Carro carro = new Carro();
        carro.acelera();

        Motocicleta moto = new Motocicleta();
        moto.acelera();

    }

}
